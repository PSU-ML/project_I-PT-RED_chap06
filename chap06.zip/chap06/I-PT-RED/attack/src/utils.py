import torch
import torch.nn.functional as F
import random


device = 'cuda' if torch.cuda.is_available() else 'cpu'


def pattern_craft(im_size, pattern_type, perturbation_size):
    ## TO DO ##
    
    # return perturbation
    pass


def add_backdoor(image, perturbation):
    ## TO DO ##
    
    # return image_perturbed
    pass


